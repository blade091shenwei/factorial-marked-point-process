import cPickle
import gensim
from os.path import abspath
import numpy as np

def train_and_saveLDA(sCorpus, sDict, sModel, num_topics):
    processed_docs = cPickle.load(file(abspath(sCorpus), 'r'))
    word_count_dict = gensim.corpora.Dictionary(processed_docs)
    word_count_dict.save(abspath(sDict))
    bag_of_words_corpus = [word_count_dict.doc2bow(pdoc) for pdoc in processed_docs]
    lda_model = gensim.models.LdaModel(bag_of_words_corpus, num_topics=num_topics, id2word=word_count_dict)
    lda_model.save(abspath(sModel))

def load_and_predictLDA(sCorpus, sModel, sDict):
    processed_docs = cPickle.load(file(abspath(sCorpus), 'r'))
    lda_model = gensim.models.LdaModel.load(abspath(sModel))
    dictionary = gensim.corpora.Dictionary.load(abspath(sDict))
    for tokens in processed_docs:
        print tokens
        print lda_model.get_document_topics(dictionary.doc2bow(tokens))

def load_and_generate_vector(tokens, sModel, sDict,
                             Binary = False, minimum_probability = 0):
    lda_model = gensim.models.LdaModel.load(sModel)
    dictionary = gensim.corpora.Dictionary.load(sDict)
    v = np.zeros(lda_model.num_topics)
    for e in lda_model.get_document_topics(dictionary.doc2bow(tokens),
                        minimum_probability = minimum_probability):
        if Binary:
            v[e[0]] = 1
        else:
            v[e[0]] = e[1]
    return v
