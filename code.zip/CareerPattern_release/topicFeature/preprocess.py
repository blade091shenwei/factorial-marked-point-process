from gensim.utils import simple_preprocess
from gensim.parsing.preprocessing import STOPWORDS
from nltk.stem.wordnet import WordNetLemmatizer
import enchant
import cPickle
from os.path import abspath

def simple_tokenize( text ):
    lmtzr = WordNetLemmatizer()
    return [lmtzr.lemmatize(token) for token in simple_preprocess(text) if
            lmtzr.lemmatize(token) not in STOPWORDS]

def simple_tokenizeDict( text ):
    dict = enchant.Dict("en_US")
    lmtzr = WordNetLemmatizer()
    tokens = [lmtzr.lemmatize(token) for token in simple_preprocess(text) if
            lmtzr.lemmatize(token) not in STOPWORDS]
    return [token for token in tokens if dict.check(token)]

def process_and_save_corpus(docs, sCorpus, Dict = False):
    if Dict:
        processed_docs = [simple_tokenizeDict(doc) for doc in docs]
    else:
        processed_docs = [simple_tokenize(doc) for doc in docs]
    cPickle.dump(processed_docs, file(abspath(sCorpus), 'w'), -1)

def process(doc, Dict = False):
    if Dict:
        return simple_tokenizeDict(doc)
    else:
        return simple_tokenize(doc)